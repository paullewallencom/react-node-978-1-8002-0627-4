import React from 'react';
import Layout from '../core/Layout';

const Private = () => (
    <Layout>
        <h1>Private page</h1>
    </Layout>
);

export default Private;
